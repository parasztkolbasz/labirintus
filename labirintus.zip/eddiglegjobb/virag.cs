using Godot;
using System;

public partial class Virag : Area2D
{
	private bool playerInArea = false;

	public override void _Ready()
	{
		// Összekötjük a szignálokat a kóddal
		BodyEntered += OnBodyEntered;
		BodyExited += OnBodyExited;
	}

	public override void _Process(double delta)
	{
		// Ha bent van a játékos ÉS megnyomja az 'E' betűt
		if (playerInArea && Input.IsActionJustPressed("interact"))
		{
			PickUp();
		}
	}

	private void OnBodyEntered(Node2D body)
	{
		// Ellenőrizzük, hogy a játékos lépett-e be (név vagy típus alapján)
		if (body.Name == "player") 
		{
			playerInArea = true;
		}
	}

	private void OnBodyExited(Node2D body)
	{
		if (body.Name == "player")
		{
			playerInArea = false;
		}
	}

	private void PickUp()
	{
		// Itt tűnik el a virág
		QueueFree();
	}
}
